<?php

/**
 * @deprecated 2020-06-04 use taskrunner instead
 */

include __DIR__ . '/taskrunner.php';
